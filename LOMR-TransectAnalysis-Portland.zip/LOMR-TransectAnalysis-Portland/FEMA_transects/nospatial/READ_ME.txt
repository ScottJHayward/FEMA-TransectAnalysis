for these transects, FEMA did not provide any sort of spatial data.

New transects will be interpolated from LIDAR and ADCIRC topo grids.

Include a CSV with the start/end points for each transect, called 'start_end.csv'